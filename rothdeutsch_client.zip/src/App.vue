<template>
  <div
    id="app"
    class="
      container
      d-flex
      flex-column
      justify-content-center
      align-items-center
      mt-5
    "
  >
    <h3>Willkommen bei der Service Worker Untersuchung!</h3>
    <ButtonGet @get="fetchData"></ButtonGet>
    <CardView :employees="employees" @del="delEmployee"></CardView>
  </div>
</template>

<script>
import ButtonGet from '@/components/ButtonGet.vue';
import CardView from '@/components/CardView.vue';
import axios from 'axios';

export default {
  name: 'app',
  components: {
    ButtonGet,
    CardView,
  },
  data() {
    return {
      employees: [],
    };
  },
  created() {
    document.addEventListener('swUpdated', this.updateAvailable, {
      once: true,
    });
  },
  methods: {
    async fetchData() {
      let res = await axios.get('http://localhost:3000/employees');
      this.employees = res.data;
    },
    async delEmployee(e) {
      await axios.delete(`${process.env.VUE_APP_SERVER}/employees/${e.id}`);
      this.fetchData();
    },
    updateAvailable() {
      alert('Heast! Es gibt ein neues Update!');
    },
  },
};
</script>

<style></style>
